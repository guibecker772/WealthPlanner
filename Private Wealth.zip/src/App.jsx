// src/App.jsx
import React from "react";
import AppRoutes from "./routes/AppRoutes.jsx";

export default function App() {
  return <AppRoutes />;
}
