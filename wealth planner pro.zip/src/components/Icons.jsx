import React from 'react';

export const DollarSign = () => <span>💲</span>;
export const Flag = () => <span>🚩</span>;
export const ShieldCheck = () => <span>🛡️</span>;
export const Settings = () => <span>⚙️</span>;
export const Menu = () => <span>☰</span>;
export const Copy = () => <span>📄</span>;
export const Plus = () => <span>➕</span>;
export const Unlock = () => <span>🔓</span>;
export const Lock = () => <span>🔒</span>;
export const LogOut = () => <span>⏏️</span>;
export const Target = () => <span>🎯</span>;
export const Trash2 = () => <span>🗑️</span>;
